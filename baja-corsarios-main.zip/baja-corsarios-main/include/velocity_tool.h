#ifndef VELOCITY_TOOL_H
#define VELOCITY_TOOL_H

void velocity_tool_init(void *p1);

#endif /* VELOCITY_TOOL_H */

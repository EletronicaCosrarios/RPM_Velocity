#ifndef TESTER_H
#define TESTER_H

void tester_mode_init(void *p1);

#endif /* TESTER_H */

#ifndef MOTOR_RPM_H
#define MOTOR_RPM_H

void motor_rpm_init(void *p1);

#endif /* MOTOR_RPM_H */

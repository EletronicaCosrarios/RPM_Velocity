#ifndef WIFI_INIT_H
#define WIFI_INIT_H

void wifi_init(void);

#endif /* WIFI_INIT_H */

# Código da Eletroeletrônica

Esse código funciona com a versão da ESP-IDF 4.4.
> Versões acima não é garantido de funcionar.